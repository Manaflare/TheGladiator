Diagonal walkcycle and runcycle for LPC figures, licensed CC-By-Sa 3.0/GPL 3.0

by Wolthera van Hövell tot Westerflier

Based on the original LPC walkcycles by Stephen Challener (AKA Redshrike)
