Artwork created by Luis Zuno (@ansimuz)

Contents

/PSD
Contains a working PSD file in case you want to make modifications

/Spritsheets
PNG files Spritesheets for hero and characters animations

/tileset
PNG files with transparency for the town

Get more resources at ansimuz.com

